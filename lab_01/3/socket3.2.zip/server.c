#include <sys/types.h> 
#include <sys/socket.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/un.h>

#define SOCKET "server.socket"
#define BUFFER_SIZE 64


static int sock_fd;

void sigint_handler() 
{
    close(sock_fd);
    unlink(SOCKET);
    exit(0);
}

int main(void)
{
	sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
	if (sock_fd == -1)
	{
		perror("Socket");
		return -1;
	}
	
	struct sockaddr addr;
	addr.sa_family = AF_UNIX;
	strcpy(addr.sa_data, SOCKET);
	
	if (bind(sock_fd, &addr, sizeof(addr)) == -1) 
	{
		perror("Bind");
		return -1;
	}
	
	struct sockaddr client_addr;
	int addrlen = sizeof(client_addr);
	
	if (signal(SIGINT, sigint_handler) == (void *)-1)
    {
        perror("Can't signal()");
        exit(1);
    }

	char buf[BUFFER_SIZE];
    char copy_buf[BUFFER_SIZE];

	
    int bytes_read;
	while(1)
	{
		printf("recv()\n");
        if ((bytes_read = recvfrom(sock_fd, buf, BUFFER_SIZE, 0, &client_addr, &addrlen)) == -1)
        {
            perror("Can't recvfrom()");
            exit(1);
        }  
        
        buf[bytes_read] = '\0';
        printf("%s\n", buf);

        sleep(1);

        sprintf(copy_buf, "%d: %s\n", getpid(), buf);
        printf("send())\n");
        if (sendto(sock_fd, copy_buf, strlen(copy_buf) + 1, 0, &client_addr, addrlen) == -1)
        {
            perror("Can't sendto()");
            exit(1);
        }
	}
	
	return 0;
}