#include <sys/types.h> 
#include <sys/socket.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#define SERVER_SOCKET "server.socket"
#define CLIENT_SOCKET "client.socket"
#define BUFFER_SIZE 64

int main(void)
{
	int sockfd = socket(AF_UNIX, SOCK_DGRAM, 0);
	if  (sockfd == -1)
	{
		perror("Can't socket()");
        exit(1);
	}
	
	struct sockaddr server_addr = {.sa_family = AF_UNIX};
	strcpy(server_addr.sa_data, SERVER_SOCKET);

	struct sockaddr sockaddr = {.sa_family = AF_UNIX};
	sprintf(sockaddr.sa_data, "%d.socket", getpid());
	// sprintf(sockaddr.sa_data, "c.socket");

	
	if (bind(sockfd, &sockaddr, sizeof(sockaddr)) == -1)
	{
		perror("Can't bind()");
        exit(1);
	}
	
	char buf[BUFFER_SIZE];
    sprintf(buf, "%d", getpid());

	if (sendto(sockfd, buf, strlen(buf), 0, &server_addr, sizeof(server_addr)) == -1)
	{
	 	perror("Can't sendto()");
        exit(1);
	}
    printf("send()\n");

	int bytes_read;
    if ((bytes_read = recv(sockfd, buf, BUFFER_SIZE, 0)) == -1)
    {
        perror("Can't recvfrom()");
        exit(1);
    }
	buf[bytes_read] = '\0';
	printf("recv message: %s\n", buf);
	
	close(sockfd);
    unlink(sockaddr.sa_data);
	return 0;
}